#!/usr/bin/env bash
clear
make p01-General.out
./p01-General.out
make cleanLin