#!/usr/bin/env bash
clear
make p01-General-Color.out
./p01-General-Color.out
make cleanLin