#!/usr/bin/env bash
clear
make p01-Simple.out
./p01-Simple.out
make cleanLin